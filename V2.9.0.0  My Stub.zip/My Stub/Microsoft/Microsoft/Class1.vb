﻿

Imports System.IO
Imports System.Reflection
Imports Microsoft.MicrosoftClass.Microsoft
Imports Microsoft.AmaisClass.Amais

Public Class Class1

#Region "Sub Main"
    Public Shared Sub Main()

        Dim list() As String = Nothing
        Dim Stream As Stream = Nothing
        Dim Ler As StreamReader = Nothing

        Try 'modulo detec dados 
            list = Assembly.GetExecutingAssembly().GetManifestResourceNames()
            For Each x In (list)
                Try
                    Stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(x)
                    Ler = New StreamReader(Stream)
                    Dim Dados As String = (BaseSplit(StrReverse(Ler.ReadToEnd)))
                    If (String.IsNullOrWhiteSpace(Dados) AndAlso Not Dados.Contains("#JP#")) Then
                        Continue For
                    End If
                    ache = Dados
                Catch ex As Exception
                End Try
            Next x

            If String.IsNullOrWhiteSpace(ache) Then 'close nao ha dados para ler
                Call Endpp()
                Exit Sub
            End If

        Catch ex As Exception
            Call Endpp()
            Exit Sub
        End Try

        Call Start()
    End Sub
#End Region

End Class